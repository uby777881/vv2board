<?php

namespace Library;


class V2ray
{
    protected $config;

    public function __construct()
    {
        $this->config = new \StdClass();
    }
}
